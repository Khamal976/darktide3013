﻿# Darktide 3013 setup for zapret-discord-youtube (Flowseal) 1.9+ / 1.10.x
# Creates darktide*.bat next to every general*.bat and adds the game's domains to the user hostlist.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Say($s) { Write-Host $s }

if (-not (Test-Path (Join-Path $root 'general.bat'))) {
  Say 'ERROR: general.bat not found. Put darktide-setup.bat and darktide-setup.ps1 into the zapret folder (next to general.bat) and run again.'
  Say 'ОШИБКА: general.bat не найден. Положите darktide-setup.bat и darktide-setup.ps1 в папку zapret (рядом с general.bat) и запустите снова.'
  exit 1
}
if (-not (Test-Path (Join-Path $root 'bin\stun.bin'))) {
  Say 'ERROR: bin\stun.bin not found. This setup needs zapret-discord-youtube 1.9 or newer.'
  Say 'ОШИБКА: нет bin\stun.bin. Нужна сборка zapret-discord-youtube 1.9 или новее.'
  exit 1
}

# 1) User hostlist: Darktide + Cloudflare domains.
# Do not add CIDR, IP addresses or geosite: entries here.
$userList = Join-Path $root 'lists\list-general-user.txt'

$domains = @(
  'atoma.cloud',
  'atoma-discovery.com',
  'fatshark.services',
  'argotunnel.com',
  'cf-ipfs.com',
  'cf-ns.com',
  'cf-ns.net',
  'cf-ns.site',
  'cf-ns.tech',
  'cfargotunnel.com',
  'cfl.re',
  'cftest5.cn',
  'cftest6.cn',
  'cftest7.com',
  'cftest8.com',
  'cloudflare-cn.com',
  'cloudflare-dns.com',
  'cloudflare-ech.com',
  'cloudflare-esni.com',
  'cloudflare-gateway.com',
  'cloudflare-ipfs.com',
  'cloudflare-quic.com',
  'cloudflare.com',
  'cloudflare.net',
  'cloudflare.tv',
  'cloudflareaccess.com',
  'cloudflareanycast.net',
  'cloudflareapps.com',
  'cloudflarebolt.com',
  'cloudflarechina.cn',
  'cloudflareclient.com',
  'cloudflarecn.net',
  'cloudflareglobal.net',
  'cloudflareinsights-cn.com',
  'cloudflareinsights.com',
  'cloudflareok.com',
  'cloudflarepartners.com',
  'cloudflareperf.com',
  'cloudflareportal.com',
  'cloudflarepreview.com',
  'cloudflareprod.com',
  'cloudflareresolve.com',
  'cloudflaressl.com',
  'cloudflarestaging.com',
  'cloudflarestatus.com',
  'cloudflarestorage.com',
  'cloudflarestoragegw.com',
  'cloudflarestream.com',
  'cloudflaretest.com',
  'cloudflarewarp.com',
  'encryptedsni.com',
  'every1dns.net',
  'isbgpsafeyet.com',
  'one.one.one',
  'one.one.one.one',
  'pacloudflare.com',
  'pages.dev',
  'trycloudflare.com',
  'videodelivery.net',
  'warp.plus',
  'workers.dev'
)

$existing = @()
if (Test-Path $userList) {
  $existing = [System.IO.File]::ReadAllLines($userList)
}

$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
$merged = New-Object 'System.Collections.Generic.List[string]'

foreach ($entry in @($existing) + @($domains)) {
  $entry = $entry.Trim()
  if ($entry -and -not $entry.StartsWith('#') -and $seen.Add($entry)) {
    $merged.Add($entry)
  }
}

[System.IO.File]::WriteAllLines($userList, $merged, $utf8)
Say ("[lists] ensured {0} user hostlist entries in list-general-user.txt" -f $domains.Count)

# 2) User-owned AWS CIDR list for the Darktide UDP profile.
# Keep this separate from ipset-all.txt: updates of the zapret build may replace ipset-all.txt.
$awsIpSet = Join-Path $root 'lists\ipset-darktide-aws.txt'

$awsCidrs = @'
18.192.0.0/15
54.93.0.0/16
52.208.0.0/13
1.178.7.0/24
1.178.10.0/24
1.178.17.0/24
1.178.21.0/24
1.178.22.0/24
1.178.90.0/24
1.178.93.0/24
1.178.94.0/24
1.178.174.0/24
3.2.70.0/23
3.2.72.0/24
3.2.79.0/24
3.2.83.0/24
3.2.84.0/24
3.2.89.0/24
3.2.93.0/24
3.2.97.0/24
3.2.109.0/24
3.2.110.0/23
3.2.112.0/22
3.5.32.0/22
3.5.52.0/22
3.5.64.0/21
3.5.72.0/22
3.5.94.0/23
3.5.96.0/22
3.5.120.0/22
3.5.126.0/23
3.5.134.0/23
3.5.136.0/22
3.5.204.0/22
3.5.216.0/22
3.5.224.0/22
3.5.244.0/22
3.5.248.0/22
3.8.0.0/14
3.40.0.0/16
3.41.0.0/17
3.64.0.0/12
3.120.0.0/13
3.248.0.0/13
5.60.96.0/19
13.36.0.0/14
13.40.0.0/14
13.48.0.0/14
13.53.0.0/16
13.60.0.0/14
13.134.0.0/15
13.154.0.0/16
13.160.0.0/16
15.129.8.0/21
15.129.29.0/24
15.129.31.0/24
15.129.36.0/23
15.129.74.0/23
15.129.78.0/24
15.129.80.0/22
15.145.0.0/22
15.145.4.0/23
15.145.8.0/21
15.145.16.0/21
15.145.24.0/23
15.160.0.0/15
15.177.68.0/23
15.177.72.0/24
15.177.74.0/23
15.177.78.0/24
15.177.89.0/24
15.177.90.0/24
15.177.97.0/24
15.177.98.0/24
15.188.0.0/16
15.193.4.0/23
15.193.140.0/22
15.193.144.0/21
15.193.152.0/22
15.216.0.0/15
15.220.48.0/21
15.220.64.0/20
15.220.144.0/23
15.220.148.0/22
15.220.152.0/21
15.220.168.0/21
15.224.0.0/16
15.236.0.0/15
16.15.12.0/22
16.15.20.0/22
16.16.0.0/16
16.18.0.0/15
16.22.0.0/16
16.60.0.0/14
16.168.0.0/14
16.192.0.0/16
16.214.16.0/20
18.89.0.0/18
18.96.32.0/19
18.96.192.0/19
18.97.192.0/18
18.98.64.0/19
18.98.160.0/19
18.98.224.0/19
18.99.96.0/20
18.99.208.0/20
18.100.0.0/15
18.102.0.0/16
18.130.0.0/16
18.132.0.0/14
18.153.0.0/16
18.156.0.0/14
18.168.0.0/14
18.175.0.0/16
18.184.0.0/15
18.192.0.0/13
18.200.0.0/14
23.254.30.0/23
34.240.0.0/12
35.42.0.0/15
35.44.0.0/15
35.50.192.0/22
35.50.196.0/23
35.54.44.0/22
35.54.52.0/24
35.54.61.0/24
35.55.16.0/21
35.55.24.0/24
35.55.40.0/23
35.55.42.0/24
35.71.72.0/22
35.71.98.0/24
35.71.101.0/24
35.71.105.0/24
35.71.111.0/24
35.71.113.0/24
35.71.120.0/23
35.152.0.0/16
35.156.0.0/14
35.176.0.0/14
35.180.0.0/15
37.203.157.0/24
40.180.0.0/15
46.51.128.0/18
46.51.192.0/20
46.137.0.0/17
46.137.128.0/18
51.0.64.0/18
51.20.0.0/15
51.24.0.0/16
51.34.0.0/16
51.44.0.0/15
51.48.0.0/15
51.92.0.0/16
51.94.0.0/15
51.96.0.0/16
51.102.0.0/16
51.118.0.0/16
51.200.0.0/14
52.16.0.0/14
52.28.0.0/14
52.46.184.0/22
52.47.0.0/16
52.48.0.0/14
52.56.0.0/14
52.94.146.0/24
52.94.248.16/28
52.94.248.112/28
52.94.248.192/28
52.94.249.32/27
52.94.249.128/28
52.94.249.240/28
52.94.250.0/28
52.95.224.0/24
52.95.227.0/24
52.95.239.0/24
52.95.244.0/24
52.95.248.0/24
52.95.253.0/24
52.95.254.0/24
52.95.255.64/28
52.95.255.128/28
54.72.0.0/14
54.76.0.0/15
54.78.0.0/16
54.154.0.0/15
54.170.0.0/15
54.194.0.0/15
54.216.0.0/15
54.220.0.0/16
54.228.0.0/15
54.246.0.0/15
56.228.0.0/16
63.32.0.0/14
63.176.0.0/12
63.246.112.0/23
64.66.138.0/23
64.66.141.0/24
64.66.144.0/24
64.66.147.0/24
64.66.154.0/24
64.66.158.0/24
64.66.160.0/24
64.73.201.0/24
64.252.82.0/23
64.252.84.0/22
64.252.88.0/23
64.252.114.0/23
64.252.116.0/23
64.252.126.0/24
66.36.3.0/24
66.36.4.0/23
66.36.8.0/24
70.232.124.0/22
75.45.128.0/18
79.125.0.0/17
83.119.128.0/18
86.112.0.0/15
89.60.0.0/15
96.0.24.0/21
96.0.32.0/22
99.10.0.0/18
99.77.55.0/30
99.77.55.12/30
99.77.55.24/30
99.77.55.32/28
99.77.55.49/32
99.77.55.50/31
99.77.55.52/30
99.77.55.56/32
99.77.55.253/32
99.77.55.254/31
99.77.133.0/24
99.77.134.0/23
99.77.136.0/23
99.77.138.0/24
99.77.155.0/24
99.77.156.0/22
99.77.245.0/24
99.77.246.0/23
99.77.248.0/23
99.77.250.0/24
99.80.0.0/15
99.150.16.0/21
99.150.40.0/21
99.150.64.0/20
99.150.80.0/21
99.151.64.0/21
99.151.80.0/20
99.151.188.0/23
99.200.0.0/13
108.128.0.0/13
136.18.142.0/23
151.148.34.0/23
151.148.41.0/24
162.213.232.0/22
173.83.196.0/23
173.83.206.0/23
173.83.208.0/24
173.83.214.0/23
173.83.216.0/24
173.83.220.0/24
173.83.223.0/24
176.34.64.0/18
176.34.128.0/17
185.48.120.0/22
195.17.0.0/24
208.78.132.0/23
208.78.135.0/24
208.86.90.0/23
216.39.136.0/21
216.39.152.0/21
216.198.196.0/22
216.198.200.0/21
216.198.208.0/22
216.198.212.0/23
216.198.228.0/23
216.198.230.0/24
216.198.238.0/23
216.198.244.0/22
216.198.248.0/23
216.244.9.0/24
216.244.10.0/23
216.244.14.0/23
216.244.16.0/21
216.244.38.0/23
'@ -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique

[System.IO.File]::WriteAllLines($awsIpSet, $awsCidrs, $utf8)
Say ("[lists] wrote {0} AWS CIDR entries to ipset-darktide-aws.txt" -f $awsCidrs.Count)

# 3) darktide*.bat from every general*.bat
$udpProfile = '--filter-udp=35000-36000 --ipset="%LISTS%ipset-darktide-aws.txt" --dpi-desync=fake --dpi-desync-any-protocol=1 --dpi-desync-repeats=10 --dpi-desync-fake-unknown-udp="%BIN%stun.bin" --dpi-desync-cutoff=n2 --new ^'
$made = 0
Get-ChildItem -Path $root -Filter 'general*.bat' | ForEach-Object {
  $src = $_.FullName
  $dst = Join-Path $root ($_.Name -replace '^general', 'darktide')
  $text = [System.IO.File]::ReadAllText($src, $utf8)
  $text = $text.Replace('cd /d %BIN%', 'cd /d "%BIN%"')
  if ($text -notmatch '--wf-udp=') { Say ("[skip] " + $_.Name + ": no --wf-udp"); return }
  # a) let winws see the hub ports
  $text = $text -replace '--wf-udp=', '--wf-udp=35000-36000,'
  # b) first profile: fake STUN before any UDP to the hub ports
  $lines = $text -split "`r?`n"
  $out = New-Object System.Collections.Generic.List[string]
  $inserted = $false
  $killed = $false
  foreach ($line in $lines) {
    $out.Add($line)
    if (-not $killed -and $line -match '^cd /d "%~dp0"') { $out.Add('tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" >nul && taskkill /IM winws.exe /F >nul'); $out.Add('sc stop WinDivert >nul 2>&1'); $out.Add('sc delete WinDivert >nul 2>&1'); $killed = $true }
    if (-not $inserted -and $line -match 'winws\.exe' -and $line -match '--wf-udp=') { $out.Add($udpProfile); $inserted = $true }
  }
  if (-not $inserted) { Say ("[skip] " + $_.Name + ": winws line not found"); return }
  # c) if the strategy has a game-filter UDP profile, use the STUN payload there too (community fix)
  $result = ($out -join "`r`n") -replace 'ACTIVE_GAME_UDP\.bin', 'stun.bin'
  $result = $result -replace 'stun2\.bin', 'stun.bin'
  [System.IO.File]::WriteAllText($dst, $result, $utf8)
  $made++
  Say ("[ok] " + (Split-Path -Leaf $dst))
}
Say ''
Say ("Done: " + $made + " darktide*.bat created.")
Say 'Next: run darktide.bat as administrator (or the darktide (ALTn).bat matching the strategy that works for you), keep the window open, start the game.'
Say 'Дальше: запустите darktide.bat от администратора (или darktide (ALTn).bat той стратегии, что работает у вас), не закрывайте окно, запустите игру.'